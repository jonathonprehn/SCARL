#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 3 "scarl_tokens.y"

#include <stdio.h>

int yylex(void);
void yyerror(char *);

int yydebug = 1;

/*for counting line numbers. Lines are incremented in scarl.l*/
extern unsigned lineNumber;
/*handled in scarl.l. for hinting at where error occured*/
extern char *lastTokenText;

/*for performing actions on the code file*/
/*for the compiling unit, this is intermediatary code*/
extern FILE *codeFile;

#line 30 "y.tab.c"
#define IDENTIFIER 257
#define PLUS 258
#define MINUS 259
#define STAR 260
#define SLASH 261
#define BANG 262
#define BOOL 263
#define INT 264
#define CHAR 265
#define POINTER 266
#define VOID 267
#define LPAREN 268
#define RPAREN 269
#define GTR 270
#define LESS 271
#define GTR_EQ 272
#define LESS_EQ 273
#define DBL_EQ 274
#define EQ 275
#define NOT_EQ 276
#define OR 277
#define AND 278
#define COMMA 279
#define SEMICOLON 280
#define IF 281
#define ELSE 282
#define WHILE 283
#define LBRACE 284
#define RBRACE 285
#define DECIMAL 286
#define OCTAL 287
#define HEX 288
#define BINARY 289
#define LIGHT_ACTUATOR 290
#define SERVO_ACTUATOR 291
#define SOUND_SENSOR 292
#define LIGHT_SENSOR 293
#define DISTANCE_SENSOR 294
#define TEMPERATURE_SENSOR 295
#define TRUE 296
#define FALSE 297
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    1,    1,    2,    2,    2,    6,    6,    7,    7,
    8,    8,    8,    8,    8,    8,    3,   14,    4,    5,
    9,   10,   11,   11,   12,   17,   17,   17,   19,   19,
   19,   18,   16,   21,   21,   22,   22,   23,   23,   23,
   24,   24,   24,   24,   24,   25,   25,   26,   26,   26,
   27,   27,   27,   28,   28,   28,   20,   20,   20,   20,
   29,   29,   29,   29,   30,   30,   15,   15,   15,   15,
   15,   13,   13,   13,   13,   13,   13,
};
short yylen[] = {                                         2,
    1,    1,    2,    1,    1,    1,    2,    3,    1,    2,
    1,    1,    1,    1,    1,    1,    3,    2,    4,    5,
    4,    2,    5,    7,    5,    0,    1,    3,    0,    1,
    3,    4,    1,    1,    3,    1,    3,    1,    3,    3,
    1,    3,    3,    3,    3,    1,    2,    1,    3,    3,
    1,    3,    3,    1,    2,    3,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,
};
short yydefred[] = {                                      0,
   67,   68,   69,   70,   71,   72,   73,   74,   75,   76,
   77,    0,    1,    0,    4,    5,    6,    0,    0,    0,
    3,    0,    0,    0,   18,   17,    0,    0,    0,    0,
    0,    0,   61,   62,   63,   64,   65,   66,    0,   60,
   54,    0,    0,    0,    0,   41,    0,    0,   51,   58,
   59,    0,    0,    0,   55,   47,    0,   19,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   28,    0,   20,    0,    0,   56,    0,    0,    0,    0,
   42,   43,   44,   45,    0,    0,   52,   53,    0,    0,
    0,    7,   11,   12,    0,    0,   13,   14,   15,   16,
    0,    0,   32,    0,    0,    0,    0,    8,   10,   22,
   31,    0,    0,    0,   21,    0,    0,    0,   25,    0,
   24,
};
short yydgoto[] = {                                      12,
   13,   14,   15,   16,   17,   94,   95,   96,   97,   98,
   99,  100,   18,   19,   20,   39,   28,   40,   74,   41,
   42,   43,   44,   45,   46,   47,   48,   49,   50,   51,
};
short yysindex[] = {                                   -189,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -189,    0,    0,    0, -252, -220, -248,
    0, -266, -108, -255,    0,    0, -249, -247, -221, -251,
 -255, -251,    0,    0,    0,    0,    0,    0, -228,    0,
    0, -208, -206, -150, -186,    0, -159, -125,    0,    0,
    0, -108, -176, -230,    0,    0, -215,    0, -255, -255,
 -255, -255, -255, -255, -255, -255, -251, -251, -251, -251,
    0, -174,    0, -151, -132,    0, -206, -150, -186, -186,
    0,    0,    0,    0, -125, -125,    0,    0, -141, -139,
 -130,    0,    0,    0, -115, -144,    0,    0,    0,    0,
  -97, -100,    0, -230, -255, -255, -255,    0,    0,    0,
    0,  -96,  -83,  -76,    0, -176, -176,  -79,    0, -176,
    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  201,    0,    0,    0,    0,    0,    0,
    0,    0,  -62,    0,    0,    0,  -60,    0, -128,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0, -199, -257, -259,  -95,    0,  -47, -105,    0,    0,
    0,  -62,    0,  -53,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  -49,    0, -152, -198,  -72,  -37,
    0,    0,    0,    0,  -82,  -59,    0,    0,    0,    0,
    0,    0,    0,    0,    0,  -50,    0,    0,    0,    0,
    0,    0,    0,  -53,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -169,    0,    0,
    0,
};
short yygindex[] = {                                      0,
  214,    0,    0,  -57,    0,  -52,  138,    0,    0,    0,
    0,    0,    0,  -23,    0,  -81,  184,  -56,  134,  -51,
    0,  183,  185,   99,   -3,  212,   95,  -19,    0,    0,
};
#define YYTABLESIZE 245
short yytable[] = {                                      27,
   73,   29,   75,   30,   22,   29,   31,   30,   25,   36,
   55,   34,   32,   26,   93,  102,   32,   36,   36,   34,
   36,   53,   34,  112,  113,  114,   29,   56,   27,   52,
   33,   34,   35,   36,   33,   34,   35,   36,   93,  102,
   37,   38,   67,   68,   37,   38,   54,   23,  101,   87,
   88,   58,   75,   76,   24,   33,   34,   35,   36,   81,
   82,   83,   84,  118,  119,   37,   38,  121,   59,   33,
   37,   60,  101,    1,    2,    3,    4,    5,   37,   37,
   33,   37,   89,   63,   64,   65,   66,   23,    1,    2,
    3,    4,    5,   23,   23,   23,   23,   23,   67,   68,
    6,    7,    8,    9,   10,   11,   90,   72,   91,   72,
   92,   23,   89,   23,   23,   23,   35,  103,    1,    2,
    3,    4,    5,   61,   35,   62,   54,   35,  106,   57,
   57,   57,   57,  105,   69,   70,   90,  107,   91,   72,
   57,   57,   57,   57,   57,   57,  104,   57,   57,   57,
   57,   57,   48,   48,    1,    2,    3,    4,    5,   79,
   80,   85,   86,   48,   48,   48,   48,   48,   48,  108,
   48,   48,   48,   38,   48,   49,   49,   24,   38,  110,
   38,   38,   38,  115,   38,  116,   49,   49,   49,   49,
   49,   49,  117,   49,   49,   49,   39,   49,   50,   50,
    2,   39,  120,   39,   39,   39,   26,   39,   27,   50,
   50,   50,   50,   50,   50,   29,   50,   50,   50,   30,
   50,   46,   46,   46,   46,   46,   46,   21,   46,   46,
   46,   40,   46,  109,    9,   71,   40,  111,   40,   40,
   40,   77,   40,   57,   78,
};
short yycheck[] = {                                      23,
   53,  257,   54,  259,  257,  257,  262,  259,  257,  269,
   30,  269,  268,  280,   72,   72,  268,  277,  278,  277,
  280,  269,  280,  105,  106,  107,  257,   31,   52,  279,
  286,  287,  288,  289,  286,  287,  288,  289,   96,   96,
  296,  297,  258,  259,  296,  297,  268,  268,   72,   69,
   70,  280,  104,  269,  275,  286,  287,  288,  289,   63,
   64,   65,   66,  116,  117,  296,  297,  120,  277,  269,
  269,  278,   96,  263,  264,  265,  266,  267,  277,  278,
  280,  280,  257,  270,  271,  272,  273,  257,  263,  264,
  265,  266,  267,  263,  264,  265,  266,  267,  258,  259,
  290,  291,  292,  293,  294,  295,  281,  284,  283,  284,
  285,  281,  257,  283,  284,  285,  269,  269,  263,  264,
  265,  266,  267,  274,  277,  276,  268,  280,  268,  258,
  259,  260,  261,  275,  260,  261,  281,  268,  283,  284,
  269,  270,  271,  272,  273,  274,  279,  276,  277,  278,
  279,  280,  258,  259,  263,  264,  265,  266,  267,   61,
   62,   67,   68,  269,  270,  271,  272,  273,  274,  285,
  276,  277,  278,  269,  280,  258,  259,  275,  274,  280,
  276,  277,  278,  280,  280,  269,  269,  270,  271,  272,
  273,  274,  269,  276,  277,  278,  269,  280,  258,  259,
    0,  274,  282,  276,  277,  278,  269,  280,  269,  269,
  270,  271,  272,  273,  274,  269,  276,  277,  278,  269,
  280,  269,  270,  271,  272,  273,  274,   14,  276,  277,
  278,  269,  280,   96,  285,   52,  274,  104,  276,  277,
  278,   59,  280,   32,   60,
};
#define YYFINAL 12
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 297
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"IDENTIFIER","PLUS","MINUS",
"STAR","SLASH","BANG","BOOL","INT","CHAR","POINTER","VOID","LPAREN","RPAREN",
"GTR","LESS","GTR_EQ","LESS_EQ","DBL_EQ","EQ","NOT_EQ","OR","AND","COMMA",
"SEMICOLON","IF","ELSE","WHILE","LBRACE","RBRACE","DECIMAL","OCTAL","HEX",
"BINARY","LIGHT_ACTUATOR","SERVO_ACTUATOR","SOUND_SENSOR","LIGHT_SENSOR",
"DISTANCE_SENSOR","TEMPERATURE_SENSOR","TRUE","FALSE",
};
char *yyrule[] = {
"$accept : program",
"program : statement_list",
"statement_list : statement",
"statement_list : statement statement_list",
"statement : device_declarator_statement",
"statement : primitive_definition_statement",
"statement : function_definition_statement",
"block_statement : LBRACE RBRACE",
"block_statement : LBRACE statement_list_block_level RBRACE",
"statement_list_block_level : statement_block_level",
"statement_list_block_level : statement_block_level statement_list_block_level",
"statement_block_level : primitive_definition_statement",
"statement_block_level : block_statement",
"statement_block_level : variable_set_statement",
"statement_block_level : function_invocation_statement",
"statement_block_level : if_block_statement",
"statement_block_level : while_block_statement",
"device_declarator_statement : device_type IDENTIFIER SEMICOLON",
"primitive_declarator : primitive_type IDENTIFIER",
"primitive_definition_statement : primitive_declarator EQ expression SEMICOLON",
"function_definition_statement : primitive_declarator LPAREN formal_parameter_list RPAREN block_statement",
"variable_set_statement : IDENTIFIER EQ expression SEMICOLON",
"function_invocation_statement : function_invocation SEMICOLON",
"if_block_statement : IF LPAREN expression RPAREN block_statement",
"if_block_statement : IF LPAREN expression RPAREN block_statement ELSE block_statement",
"while_block_statement : WHILE LPAREN expression RPAREN block_statement",
"formal_parameter_list :",
"formal_parameter_list : primitive_declarator",
"formal_parameter_list : primitive_declarator COMMA formal_parameter_list",
"parameter_list :",
"parameter_list : unit",
"parameter_list : unit COMMA parameter_list",
"function_invocation : IDENTIFIER LPAREN parameter_list RPAREN",
"expression : logical_expression",
"logical_expression : logical_and_expression",
"logical_expression : logical_expression OR logical_and_expression",
"logical_and_expression : equality_expression",
"logical_and_expression : logical_and_expression AND equality_expression",
"equality_expression : relational_expression",
"equality_expression : equality_expression DBL_EQ relational_expression",
"equality_expression : equality_expression NOT_EQ relational_expression",
"relational_expression : bool_expression",
"relational_expression : relational_expression GTR bool_expression",
"relational_expression : relational_expression LESS bool_expression",
"relational_expression : relational_expression GTR_EQ bool_expression",
"relational_expression : relational_expression LESS_EQ bool_expression",
"bool_expression : arithmetic_expression",
"bool_expression : BANG bool_expression",
"arithmetic_expression : arithmetic_factor",
"arithmetic_expression : arithmetic_expression PLUS arithmetic_factor",
"arithmetic_expression : arithmetic_expression MINUS arithmetic_factor",
"arithmetic_factor : arithmetic_unary",
"arithmetic_factor : arithmetic_factor STAR arithmetic_unary",
"arithmetic_factor : arithmetic_factor SLASH arithmetic_unary",
"arithmetic_unary : unit",
"arithmetic_unary : MINUS arithmetic_unary",
"arithmetic_unary : LPAREN arithmetic_expression RPAREN",
"unit : IDENTIFIER",
"unit : integer_value",
"unit : bool_value",
"unit : function_invocation",
"integer_value : DECIMAL",
"integer_value : OCTAL",
"integer_value : HEX",
"integer_value : BINARY",
"bool_value : TRUE",
"bool_value : FALSE",
"primitive_type : BOOL",
"primitive_type : INT",
"primitive_type : CHAR",
"primitive_type : POINTER",
"primitive_type : VOID",
"device_type : LIGHT_ACTUATOR",
"device_type : SERVO_ACTUATOR",
"device_type : SOUND_SENSOR",
"device_type : LIGHT_SENSOR",
"device_type : DISTANCE_SENSOR",
"device_type : TEMPERATURE_SENSOR",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 147 "scarl_tokens.y"

void yyerror(char *s) {
	fprintf(stderr, "%s at line %i near \'%s\'\n", s, lineNumber, lastTokenText);
}
#line 334 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
