#ifndef __SCARL_AST_VISITOR_FUNCTIONS_H__
#define __SCARL_AST_VISITOR_FUNCTIONS_H__

#include "scarlast.h"

void NON_TERMINAL_PROGRAM_func(struct ast_node *);
void NON_TERMINAL_STATEMENT_LIST_func(struct ast_node *);
void NON_TERMINAL_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_BLOCK_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_STATEMENT_LIST_BLOCK_LEVEL_func(struct ast_node *);
void NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(struct ast_node *);
void NON_TERMINAL_DEVICE_DECLARATOR_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_PRIMITIVE_DECLARATOR_func(struct ast_node *);
void NON_TERMINAL_PRIMITIVE_DEFINITION_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_FUNCTION_DEFINITION_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_VARIABLE_SET_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_FUNCTION_INVOCATION_func(struct ast_node *);
void NON_TERMINAL_FUNCTION_INVOCATION_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_IF_BLOCK_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_WHILE_BLOCK_STATEMENT_func(struct ast_node *);
void NON_TERMINAL_FORMAL_PARAMETER_LIST_func(struct ast_node *);
void NON_TERMINAL_PARAMETER_LIST_func(struct ast_node *);
void NON_TERMINAL_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_LOGICAL_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_LOGICAL_AND_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_EQUALITY_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_RELATIONAL_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_BOOL_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_ARITHMETIC_EXPRESSION_func(struct ast_node *);
void NON_TERMINAL_ARITHMETIC_FACTOR_func(struct ast_node *);
void NON_TERMINAL_ARITHMETIC_UNARY_func(struct ast_node *);
void NON_TERMINAL_UNIT_func(struct ast_node *);
void NON_TERMINAL_INTEGER_VALUE_func(struct ast_node *);
void NON_TERMINAL_BOOL_VALUE_func(struct ast_node *);
void NON_TERMINAL_PRIMITIVE_TYPE_func(struct ast_node *);
void NON_TERMINAL_DEVICE_TYPE_func(struct ast_node *);
void TERMINAL_IDENTIFIER_func(struct ast_node *nod);
void TERMINAL_PLUS_func(struct ast_node *nod);
void TERMINAL_MINUS_func(struct ast_node *nod);
void TERMINAL_STAR_func(struct ast_node *nod);
void TERMINAL_SLASH_func(struct ast_node *nod);
void TERMINAL_BANG_func(struct ast_node *nod);
void TERMINAL_BOOL_func(struct ast_node *nod);
void TERMINAL_INT_func(struct ast_node *nod);
void TERMINAL_CHAR_func(struct ast_node *nod);
void TERMINAL_POINTER_func(struct ast_node *nod);
void TERMINAL_VOID_func(struct ast_node *nod);
void TERMINAL_LPAREN_func(struct ast_node *nod);
void TERMINAL_RPAREN_func(struct ast_node *nod);
void TERMINAL_GTR_func(struct ast_node *nod);
void TERMINAL_LESS_func(struct ast_node *nod);
void TERMINAL_GTR_EQ_func(struct ast_node *nod);
void TERMINAL_LESS_EQ_func(struct ast_node *nod);
void TERMINAL_DBL_EQ_func(struct ast_node *nod);
void TERMINAL_EQ_func(struct ast_node *nod);
void TERMINAL_NOT_EQ_func(struct ast_node *nod);
void TERMINAL_OR_func(struct ast_node *nod);
void TERMINAL_AND_func(struct ast_node *nod);
void TERMINAL_COMMA_func(struct ast_node *nod);
void TERMINAL_SEMICOLON_func(struct ast_node *nod);
void TERMINAL_IF_func(struct ast_node *nod);
void TERMINAL_ELSE_func(struct ast_node *nod);
void TERMINAL_WHILE_func(struct ast_node *nod);
void TERMINAL_LBRACE_func(struct ast_node *nod);
void TERMINAL_RBRACE_func(struct ast_node *nod);
void TERMINAL_DECIMAL_func(struct ast_node *nod);
void TERMINAL_OCTAL_func(struct ast_node *nod);
void TERMINAL_HEX_func(struct ast_node *nod);
void TERMINAL_BINARY_func(struct ast_node *nod);
void TERMINAL_LIGHT_ACTUATOR_func(struct ast_node *nod);
void TERMINAL_SERVO_ACTUATOR_func(struct ast_node *nod);
void TERMINAL_SOUND_SENSOR_func(struct ast_node *nod);
void TERMINAL_LIGHT_SENSOR_func(struct ast_node *nod);
void TERMINAL_DISTANCE_SENSOR_func(struct ast_node *nod);
void TERMINAL_TEMPERATURE_SENSOR_func(struct ast_node *nod);
void TERMINAL_TRUE_func(struct ast_node *nod);
void TERMINAL_FALSE_func(struct ast_node *nod);


void init_visitor_func_parsing_constructs();

#endif