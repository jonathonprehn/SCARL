#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 3 "scarl_tokens.y"

#include <stdio.h>

#include "scarlast.h"
#include "visitors.h"

int yylex(void);
void yyerror(char *);

int yydebug = 1;

/*for counting line numbers. Lines are incremented in scarl.l*/
extern unsigned lineNumber;
/*handled in scarl.l. for hinting at where error occured*/
extern char *lastTokenText;

/*for performing actions on the code file*/
/*for the compiling unit, this is intermediatary code*/
extern FILE *codeFile;

/*for building the tree that will be used for generating the code later on*/
extern struct ast_node *syntax_tree;
/*for building the tree as well*/
extern struct ast_node *current_ast_node;

/*the stack to be used when creating nonterminal sub-ASTs*/
extern struct ast_node_stack *node_stack;
#line 40 "y.tab.c"
#define IDENTIFIER 257
#define PLUS 258
#define MINUS 259
#define STAR 260
#define SLASH 261
#define BANG 262
#define BOOL 263
#define INT 264
#define CHAR 265
#define POINTER 266
#define VOID 267
#define LPAREN 268
#define RPAREN 269
#define GTR 270
#define LESS 271
#define GTR_EQ 272
#define LESS_EQ 273
#define DBL_EQ 274
#define EQ 275
#define NOT_EQ 276
#define OR 277
#define AND 278
#define COMMA 279
#define SEMICOLON 280
#define IF 281
#define ELSE 282
#define WHILE 283
#define LBRACE 284
#define RBRACE 285
#define DECIMAL 286
#define OCTAL 287
#define HEX 288
#define BINARY 289
#define LIGHT_ACTUATOR 290
#define SERVO_ACTUATOR 291
#define SOUND_SENSOR 292
#define LIGHT_SENSOR 293
#define DISTANCE_SENSOR 294
#define TEMPERATURE_SENSOR 295
#define TRUE 296
#define FALSE 297
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    1,    1,    2,    2,    2,    6,    6,    7,    7,
    8,    8,    8,    8,    8,    8,    3,   14,    4,    5,
    9,   18,   10,   11,   11,   12,   17,   17,   17,   19,
   19,   19,   16,   20,   20,   21,   21,   22,   22,   22,
   23,   23,   23,   23,   23,   24,   24,   25,   25,   25,
   26,   26,   26,   27,   27,   27,   28,   28,   28,   28,
   29,   29,   29,   29,   30,   30,   15,   15,   15,   15,
   15,   13,   13,   13,   13,   13,   13,
};
short yylen[] = {                                         2,
    1,    1,    2,    1,    1,    1,    2,    3,    1,    2,
    1,    1,    1,    1,    1,    1,    3,    2,    4,    5,
    4,    4,    2,    5,    7,    5,    0,    1,    3,    0,
    1,    3,    1,    1,    3,    1,    3,    1,    3,    3,
    1,    3,    3,    3,    3,    1,    2,    1,    3,    3,
    1,    3,    3,    1,    2,    3,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,
};
short yydefred[] = {                                      0,
   67,   68,   69,   70,   71,   72,   73,   74,   75,   76,
   77,    0,    1,    0,    4,    5,    6,    0,    0,    0,
    3,    0,    0,    0,   18,   17,    0,    0,    0,    0,
    0,    0,   61,   62,   63,   64,   65,   66,    0,   60,
    0,    0,    0,    0,   41,    0,    0,   51,   54,   58,
   59,    0,    0,    0,   55,    0,    0,   19,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   29,    0,   20,    0,    0,   56,    0,    0,    0,    0,
   42,   43,   44,   45,    0,    0,   52,   53,    0,    0,
    0,    7,   11,   12,    0,    0,   13,   14,   15,   16,
    0,    0,    0,   22,    0,    0,    0,    8,   10,   23,
   32,    0,    0,    0,   21,    0,    0,    0,   26,    0,
   25,
};
short yydgoto[] = {                                      12,
   13,   14,   15,   16,   17,   94,   95,   96,   97,   98,
   99,  100,   18,   19,   20,   74,   28,   40,   75,   41,
   42,   43,   44,   45,   46,   47,   48,   49,   50,   51,
};
short yysindex[] = {                                   -206,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -206,    0,    0,    0, -251, -227, -247,
    0, -253, -158, -254,    0,    0, -248, -240, -219, -250,
 -250, -250,    0,    0,    0,    0,    0,    0, -236,    0,
 -205, -203, -259, -119,    0, -233, -193,    0,    0,    0,
    0, -158, -192, -254,    0, -233, -196,    0, -254, -254,
 -254, -254, -254, -254, -254, -254, -250, -250, -250, -250,
    0, -187,    0, -184, -151,    0, -203, -259, -119, -119,
    0,    0,    0,    0, -193, -193,    0,    0, -204, -139,
 -120,    0,    0,    0, -114, -153,    0,    0,    0,    0,
 -143, -125, -254,    0, -254, -254, -254,    0,    0,    0,
    0, -102,  -84,  -76,    0, -192, -192,  -88,    0, -192,
    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  195,    0,    0,    0,    0,    0,    0,
    0,    0,  -73,    0,    0,    0,  -72,    0, -136,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
 -256, -130, -258,  -31,    0,  -55, -113,    0,    0,    0,
    0,  -73,    0,  -71,    0,  -43,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  -70,    0,    0, -107, -224,  -19,   -7,
    0,    0,    0,    0,  -90,  -67,    0,    0,    0,    0,
    0,    0,    0,    0,    0,  -85,    0,    0,    0,    0,
    0,    0,  -71,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -164,    0,    0,
    0,
};
short yygindex[] = {                                      0,
  187,    0,    0,  -68,    0,  -51,  112,    0,    0,    0,
    0,    0,    0,  -22,    0,  -24,  168,  -56,  129,    0,
  180,  181,   29,  111,   84,   59,  -18,    0,    0,    0,
};
#define YYTABLESIZE 273
short yytable[] = {                                      39,
   27,   73,   29,   93,   30,   22,   29,   31,   30,   25,
   36,   55,   33,   32,   61,  102,   62,   32,   36,   36,
   36,   36,   33,   33,   67,   68,   26,   93,   53,   27,
   52,   33,   34,   35,   36,   33,   34,   35,   36,  102,
   23,   37,   38,   58,   37,   37,   38,   24,   54,  101,
   87,   88,   37,   37,   37,   37,    1,    2,    3,    4,
    5,   67,   68,   54,  118,  119,   69,   70,  121,   89,
  105,   59,   76,  101,   60,    1,    2,    3,    4,    5,
  112,  113,  114,    6,    7,    8,    9,   10,   11,   79,
   80,   72,   24,   90,  103,   91,   72,   92,   24,   24,
   24,   24,   24,   89,    1,    2,    3,    4,    5,    1,
    2,    3,    4,    5,   56,   57,   24,  104,   24,   24,
   24,   57,   57,   57,   57,   85,   86,   90,  106,   91,
   72,   24,   57,   57,   57,   57,   57,   57,   34,   57,
   57,   57,   57,   57,   48,   48,   34,  107,   34,   34,
   63,   64,   65,   66,  110,   48,   48,   48,   48,   48,
   48,   35,   48,   48,   48,   48,   48,   49,   49,   35,
  108,   35,   35,   81,   82,   83,   84,  115,   49,   49,
   49,   49,   49,   49,  116,   49,   49,   49,   49,   49,
   50,   50,  117,  120,    2,   27,   28,   30,   31,    9,
   21,   50,   50,   50,   50,   50,   50,  109,   50,   50,
   50,   50,   50,   46,   46,   46,   46,   46,   46,   71,
   46,   46,   46,   46,   46,   47,   47,   47,   47,   47,
   47,  111,   47,   47,   47,   47,   47,   38,   77,    0,
   78,    0,   38,    0,   38,   38,   38,   38,   38,   39,
    0,    0,    0,    0,   39,    0,   39,   39,   39,   39,
   39,   40,    0,    0,    0,    0,   40,    0,   40,   40,
   40,   40,   40,
};
short yycheck[] = {                                      24,
   23,   53,  257,   72,  259,  257,  257,  262,  259,  257,
  269,   30,  269,  268,  274,   72,  276,  268,  277,  278,
  279,  280,  279,  280,  258,  259,  280,   96,  269,   52,
  279,  286,  287,  288,  289,  286,  287,  288,  289,   96,
  268,  296,  297,  280,  269,  296,  297,  275,  268,   72,
   69,   70,  277,  278,  279,  280,  263,  264,  265,  266,
  267,  258,  259,  268,  116,  117,  260,  261,  120,  257,
  275,  277,  269,   96,  278,  263,  264,  265,  266,  267,
  105,  106,  107,  290,  291,  292,  293,  294,  295,   61,
   62,  284,  257,  281,  279,  283,  284,  285,  263,  264,
  265,  266,  267,  257,  263,  264,  265,  266,  267,  263,
  264,  265,  266,  267,   31,   32,  281,  269,  283,  284,
  285,  258,  259,  260,  261,   67,   68,  281,  268,  283,
  284,  275,  269,  270,  271,  272,  273,  274,  269,  276,
  277,  278,  279,  280,  258,  259,  277,  268,  279,  280,
  270,  271,  272,  273,  280,  269,  270,  271,  272,  273,
  274,  269,  276,  277,  278,  279,  280,  258,  259,  277,
  285,  279,  280,   63,   64,   65,   66,  280,  269,  270,
  271,  272,  273,  274,  269,  276,  277,  278,  279,  280,
  258,  259,  269,  282,    0,  269,  269,  269,  269,  285,
   14,  269,  270,  271,  272,  273,  274,   96,  276,  277,
  278,  279,  280,  269,  270,  271,  272,  273,  274,   52,
  276,  277,  278,  279,  280,  269,  270,  271,  272,  273,
  274,  103,  276,  277,  278,  279,  280,  269,   59,   -1,
   60,   -1,  274,   -1,  276,  277,  278,  279,  280,  269,
   -1,   -1,   -1,   -1,  274,   -1,  276,  277,  278,  279,
  280,  269,   -1,   -1,   -1,   -1,  274,   -1,  276,  277,
  278,  279,  280,
};
#define YYFINAL 12
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 297
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"IDENTIFIER","PLUS","MINUS",
"STAR","SLASH","BANG","BOOL","INT","CHAR","POINTER","VOID","LPAREN","RPAREN",
"GTR","LESS","GTR_EQ","LESS_EQ","DBL_EQ","EQ","NOT_EQ","OR","AND","COMMA",
"SEMICOLON","IF","ELSE","WHILE","LBRACE","RBRACE","DECIMAL","OCTAL","HEX",
"BINARY","LIGHT_ACTUATOR","SERVO_ACTUATOR","SOUND_SENSOR","LIGHT_SENSOR",
"DISTANCE_SENSOR","TEMPERATURE_SENSOR","TRUE","FALSE",
};
char *yyrule[] = {
"$accept : program",
"program : statement_list",
"statement_list : statement",
"statement_list : statement statement_list",
"statement : device_declarator_statement",
"statement : primitive_definition_statement",
"statement : function_definition_statement",
"block_statement : LBRACE RBRACE",
"block_statement : LBRACE statement_list_block_level RBRACE",
"statement_list_block_level : statement_block_level",
"statement_list_block_level : statement_block_level statement_list_block_level",
"statement_block_level : primitive_definition_statement",
"statement_block_level : block_statement",
"statement_block_level : variable_set_statement",
"statement_block_level : function_invocation_statement",
"statement_block_level : if_block_statement",
"statement_block_level : while_block_statement",
"device_declarator_statement : device_type IDENTIFIER SEMICOLON",
"primitive_declarator : primitive_type IDENTIFIER",
"primitive_definition_statement : primitive_declarator EQ expression SEMICOLON",
"function_definition_statement : primitive_declarator LPAREN formal_parameter_list RPAREN block_statement",
"variable_set_statement : IDENTIFIER EQ expression SEMICOLON",
"function_invocation : IDENTIFIER LPAREN parameter_list RPAREN",
"function_invocation_statement : function_invocation SEMICOLON",
"if_block_statement : IF LPAREN expression RPAREN block_statement",
"if_block_statement : IF LPAREN expression RPAREN block_statement ELSE block_statement",
"while_block_statement : WHILE LPAREN expression RPAREN block_statement",
"formal_parameter_list :",
"formal_parameter_list : primitive_declarator",
"formal_parameter_list : primitive_declarator COMMA formal_parameter_list",
"parameter_list :",
"parameter_list : expression",
"parameter_list : expression COMMA parameter_list",
"expression : logical_expression",
"logical_expression : logical_and_expression",
"logical_expression : logical_expression OR logical_and_expression",
"logical_and_expression : equality_expression",
"logical_and_expression : logical_and_expression AND equality_expression",
"equality_expression : relational_expression",
"equality_expression : equality_expression DBL_EQ relational_expression",
"equality_expression : equality_expression NOT_EQ relational_expression",
"relational_expression : bool_expression",
"relational_expression : relational_expression GTR bool_expression",
"relational_expression : relational_expression LESS bool_expression",
"relational_expression : relational_expression GTR_EQ bool_expression",
"relational_expression : relational_expression LESS_EQ bool_expression",
"bool_expression : arithmetic_expression",
"bool_expression : BANG arithmetic_expression",
"arithmetic_expression : arithmetic_factor",
"arithmetic_expression : arithmetic_expression PLUS arithmetic_factor",
"arithmetic_expression : arithmetic_expression MINUS arithmetic_factor",
"arithmetic_factor : arithmetic_unary",
"arithmetic_factor : arithmetic_factor STAR arithmetic_unary",
"arithmetic_factor : arithmetic_factor SLASH arithmetic_unary",
"arithmetic_unary : unit",
"arithmetic_unary : MINUS arithmetic_unary",
"arithmetic_unary : LPAREN arithmetic_expression RPAREN",
"unit : IDENTIFIER",
"unit : integer_value",
"unit : bool_value",
"unit : function_invocation",
"integer_value : DECIMAL",
"integer_value : OCTAL",
"integer_value : HEX",
"integer_value : BINARY",
"bool_value : TRUE",
"bool_value : FALSE",
"primitive_type : BOOL",
"primitive_type : INT",
"primitive_type : CHAR",
"primitive_type : POINTER",
"primitive_type : VOID",
"device_type : LIGHT_ACTUATOR",
"device_type : SERVO_ACTUATOR",
"device_type : SOUND_SENSOR",
"device_type : LIGHT_SENSOR",
"device_type : DISTANCE_SENSOR",
"device_type : TEMPERATURE_SENSOR",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 199 "scarl_tokens.y"

void yyerror(char *s) {
	fprintf(stderr, "%s at line %i near \'%s\'\n", s, lineNumber, lastTokenText);
}
#line 350 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 43 "scarl_tokens.y"
{ NON_TERMINAL_PROGRAM_func(current_ast_node); }
break;
case 2:
#line 45 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_LIST_func(current_ast_node); }
break;
case 3:
#line 47 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_LIST_func(current_ast_node); }
break;
case 4:
#line 49 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_func(current_ast_node); }
break;
case 5:
#line 51 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_func(current_ast_node); }
break;
case 6:
#line 53 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_func(current_ast_node); }
break;
case 7:
#line 55 "scarl_tokens.y"
{ NON_TERMINAL_BLOCK_STATEMENT_func(current_ast_node); }
break;
case 8:
#line 57 "scarl_tokens.y"
{ NON_TERMINAL_BLOCK_STATEMENT_func(current_ast_node); }
break;
case 9:
#line 59 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_LIST_BLOCK_LEVEL_func(current_ast_node); }
break;
case 10:
#line 61 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_LIST_BLOCK_LEVEL_func(current_ast_node); }
break;
case 11:
#line 63 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 12:
#line 65 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 13:
#line 67 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 14:
#line 69 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 15:
#line 71 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 16:
#line 73 "scarl_tokens.y"
{ NON_TERMINAL_STATEMENT_BLOCK_LEVEL_func(current_ast_node); }
break;
case 17:
#line 75 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_DECLARATOR_STATEMENT_func(current_ast_node); }
break;
case 18:
#line 77 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_DECLARATOR_func(current_ast_node); }
break;
case 19:
#line 79 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_DEFINITION_STATEMENT_func(current_ast_node); }
break;
case 20:
#line 81 "scarl_tokens.y"
{ NON_TERMINAL_FUNCTION_DEFINITION_STATEMENT_func(current_ast_node); }
break;
case 21:
#line 83 "scarl_tokens.y"
{ NON_TERMINAL_VARIABLE_SET_STATEMENT_func(current_ast_node); }
break;
case 22:
#line 85 "scarl_tokens.y"
{ NON_TERMINAL_FUNCTION_INVOCATION_func(current_ast_node); }
break;
case 23:
#line 87 "scarl_tokens.y"
{ NON_TERMINAL_FUNCTION_INVOCATION_STATEMENT_func(current_ast_node); }
break;
case 24:
#line 89 "scarl_tokens.y"
{ NON_TERMINAL_IF_BLOCK_STATEMENT_func(current_ast_node); }
break;
case 25:
#line 91 "scarl_tokens.y"
{ NON_TERMINAL_IF_BLOCK_STATEMENT_func(current_ast_node); }
break;
case 26:
#line 93 "scarl_tokens.y"
{ NON_TERMINAL_WHILE_BLOCK_STATEMENT_func(current_ast_node); }
break;
case 27:
#line 95 "scarl_tokens.y"
{ NON_TERMINAL_FORMAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 28:
#line 97 "scarl_tokens.y"
{ NON_TERMINAL_FORMAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 29:
#line 99 "scarl_tokens.y"
{ NON_TERMINAL_FORMAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 30:
#line 102 "scarl_tokens.y"
{ NON_TERMINAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 31:
#line 104 "scarl_tokens.y"
{ NON_TERMINAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 32:
#line 106 "scarl_tokens.y"
{ NON_TERMINAL_PARAMETER_LIST_func(current_ast_node); }
break;
case 33:
#line 108 "scarl_tokens.y"
{ NON_TERMINAL_EXPRESSION_func(current_ast_node); }
break;
case 34:
#line 110 "scarl_tokens.y"
{ NON_TERMINAL_LOGICAL_EXPRESSION_func(current_ast_node); }
break;
case 35:
#line 112 "scarl_tokens.y"
{ NON_TERMINAL_LOGICAL_EXPRESSION_func(current_ast_node); }
break;
case 36:
#line 114 "scarl_tokens.y"
{ NON_TERMINAL_LOGICAL_AND_EXPRESSION_func(current_ast_node); }
break;
case 37:
#line 116 "scarl_tokens.y"
{ NON_TERMINAL_LOGICAL_AND_EXPRESSION_func(current_ast_node); }
break;
case 38:
#line 118 "scarl_tokens.y"
{ NON_TERMINAL_EQUALITY_EXPRESSION_func(current_ast_node); }
break;
case 39:
#line 120 "scarl_tokens.y"
{ NON_TERMINAL_EQUALITY_EXPRESSION_func(current_ast_node); }
break;
case 40:
#line 122 "scarl_tokens.y"
{ NON_TERMINAL_EQUALITY_EXPRESSION_func(current_ast_node); }
break;
case 41:
#line 124 "scarl_tokens.y"
{ NON_TERMINAL_RELATIONAL_EXPRESSION_func(current_ast_node); }
break;
case 42:
#line 126 "scarl_tokens.y"
{ NON_TERMINAL_RELATIONAL_EXPRESSION_func(current_ast_node); }
break;
case 43:
#line 128 "scarl_tokens.y"
{ NON_TERMINAL_RELATIONAL_EXPRESSION_func(current_ast_node); }
break;
case 44:
#line 130 "scarl_tokens.y"
{ NON_TERMINAL_RELATIONAL_EXPRESSION_func(current_ast_node); }
break;
case 45:
#line 132 "scarl_tokens.y"
{ NON_TERMINAL_RELATIONAL_EXPRESSION_func(current_ast_node); }
break;
case 46:
#line 134 "scarl_tokens.y"
{ NON_TERMINAL_BOOL_EXPRESSION_func(current_ast_node); }
break;
case 47:
#line 136 "scarl_tokens.y"
{ NON_TERMINAL_BOOL_EXPRESSION_func(current_ast_node); }
break;
case 48:
#line 138 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_EXPRESSION_func(current_ast_node); }
break;
case 49:
#line 140 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_EXPRESSION_func(current_ast_node); }
break;
case 50:
#line 142 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_EXPRESSION_func(current_ast_node); }
break;
case 51:
#line 144 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_FACTOR_func(current_ast_node); }
break;
case 52:
#line 146 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_FACTOR_func(current_ast_node); }
break;
case 53:
#line 148 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_FACTOR_func(current_ast_node); }
break;
case 54:
#line 150 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_UNARY_func(current_ast_node); }
break;
case 55:
#line 152 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_UNARY_func(current_ast_node); }
break;
case 56:
#line 154 "scarl_tokens.y"
{ NON_TERMINAL_ARITHMETIC_UNARY_func(current_ast_node); }
break;
case 57:
#line 156 "scarl_tokens.y"
{ NON_TERMINAL_UNIT_func(current_ast_node); }
break;
case 58:
#line 158 "scarl_tokens.y"
{ NON_TERMINAL_UNIT_func(current_ast_node); }
break;
case 59:
#line 160 "scarl_tokens.y"
{ NON_TERMINAL_UNIT_func(current_ast_node); }
break;
case 60:
#line 162 "scarl_tokens.y"
{ NON_TERMINAL_UNIT_func(current_ast_node); }
break;
case 61:
#line 164 "scarl_tokens.y"
{ NON_TERMINAL_INTEGER_VALUE_func(current_ast_node); }
break;
case 62:
#line 166 "scarl_tokens.y"
{ NON_TERMINAL_INTEGER_VALUE_func(current_ast_node); }
break;
case 63:
#line 168 "scarl_tokens.y"
{ NON_TERMINAL_INTEGER_VALUE_func(current_ast_node); }
break;
case 64:
#line 170 "scarl_tokens.y"
{ NON_TERMINAL_INTEGER_VALUE_func(current_ast_node); }
break;
case 65:
#line 172 "scarl_tokens.y"
{ NON_TERMINAL_BOOL_VALUE_func(current_ast_node); }
break;
case 66:
#line 174 "scarl_tokens.y"
{ NON_TERMINAL_BOOL_VALUE_func(current_ast_node); }
break;
case 67:
#line 176 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_TYPE_func(current_ast_node); }
break;
case 68:
#line 178 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_TYPE_func(current_ast_node); }
break;
case 69:
#line 180 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_TYPE_func(current_ast_node); }
break;
case 70:
#line 182 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_TYPE_func(current_ast_node); }
break;
case 71:
#line 184 "scarl_tokens.y"
{ NON_TERMINAL_PRIMITIVE_TYPE_func(current_ast_node); }
break;
case 72:
#line 186 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
case 73:
#line 188 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
case 74:
#line 190 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
case 75:
#line 192 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
case 76:
#line 194 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
case 77:
#line 196 "scarl_tokens.y"
{ NON_TERMINAL_DEVICE_TYPE_func(current_ast_node); }
break;
#line 799 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
